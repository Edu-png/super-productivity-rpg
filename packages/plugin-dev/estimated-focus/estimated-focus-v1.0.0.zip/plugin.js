// Estimated Focus
// Opens focus mode and starts a countdown based on the active task's estimate.

var _estimatedFocusLastTaskId = null;

function _estimatedFocusGetDuration(task) {
  if (!task || !Number.isFinite(task.timeEstimate) || task.timeEstimate <= 0) {
    return 0;
  }

  var timeSpent = Number.isFinite(task.timeSpent) ? Math.max(0, task.timeSpent) : 0;
  var remaining = task.timeEstimate - timeSpent;

  // A completed estimate must not become 0 because focus mode interprets 0 as
  // Flowtime. Reuse the full estimate when the task has reached or exceeded it.
  return remaining > 0 ? remaining : task.timeEstimate;
}

PluginAPI.registerHook('currentTaskChange', function (payload) {
  var task = payload && payload.current ? payload.current : null;

  if (!task) {
    _estimatedFocusLastTaskId = null;
    return;
  }

  // The hook can be emitted more than once for the same active task. Starting
  // another session would reset a countdown that is already in progress.
  if (_estimatedFocusLastTaskId === task.id) {
    return;
  }
  _estimatedFocusLastTaskId = task.id;

  var duration = _estimatedFocusGetDuration(task);
  if (!duration) {
    PluginAPI.showSnack({
      msg: 'Add a time estimate before starting this task to use Estimated Focus.',
      type: 'INFO',
      ico: 'hourglass_empty',
    });
    return;
  }

  PluginAPI.dispatchAction({
    type: '[FocusMode] Show Overlay',
  });
  PluginAPI.dispatchAction({
    type: '[FocusMode] Start Session',
    duration: duration,
  });
});

PluginAPI.onUnload(function () {
  _estimatedFocusLastTaskId = null;
});
